import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;

import javax.annotation.Nullable;

public class LC_WAIKIKI_TEST extends BaseTest{

    HomePage homePage;
    CartPage cartPage;
    LoginPage loginPage;
    SearchPage searchPage;


    @Test
    @Order(1)
    public void login_to_the_site(){
        homePage = new HomePage(driver);
        homePage.checkHome();
        homePage.checkLogin();
        loginPage = new LoginPage(driver);
        loginPage.goToLogin();
        loginPage.visible();
        loginPage.mail();
        loginPage.password();
        loginPage.login();
        loginPage.checkInLogin();

    }
    @Test
    @Order(2)
    public void search_a_product(){
        searchPage = new SearchPage(driver);
        searchPage.inputText();
        searchPage.search();
        searchPage.downScroll();
        searchPage.scrollUp();
        searchPage.moreProduct();
        searchPage.select();
    }

    @Test
    @Order(3)
    public void check_cart(){
        cartPage = new CartPage(driver);
        cartPage.chooseSize();
        cartPage.addToCart();
        cartPage.priceRegular();
        cartPage.cartItemPrice();
        Assertions.assertNotEquals(cartPage.priceRegular(),cartPage.cartItemPrice());
        cartPage.quantityPlus();
        cartPage.checkInQuantity();
        Assertions.assertEquals(cartPage.checkInQuantity() , "2");
        cartPage.deleteCart();
        cartPage.deleteProduct();
        cartPage.cartEmpty();
    }

}
