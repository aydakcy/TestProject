import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HomePage extends BasePage{

        By checkHomeLocator = By.cssSelector(".main-header-logo > img[alt='LC Waikiki Logo']");
        By checkLoginLocator = By.cssSelector(".header-section > div:nth-of-type(1)");


    public HomePage(WebDriver driver) {
        super(driver);
    }

    public void checkHome(){
        driver.findElement(checkHomeLocator).isDisplayed();
    }

    public void checkLogin(){
        driver.findElement(checkLoginLocator).isDisplayed();
    }
}

