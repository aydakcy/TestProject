import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage extends BasePage{

    By goToLoginLocator = By.cssSelector(".header-section > div:nth-of-type(1)");
    By visibleLocator = By.cssSelector(".ul-title");
    By mailLocator = By.id("LoginEmail");
    By passwordLocator = By.id("Password");
    By loginLocator = By.id("loginLink");
    By checkInLoginLocator =By.cssSelector(".dropdown-toggle.striped-button > .dropdown-label");

    public LoginPage(WebDriver driver) {
        super(driver);
    }

    public void goToLogin(){
        click(goToLoginLocator);
    }

    public void visible(){
        driver.findElement(visibleLocator).isDisplayed();
    }

    public void mail(){
        driver.findElement(mailLocator).sendKeys("akcayayda@gmail.com");
    }

    public void password(){
        driver.findElement(passwordLocator).sendKeys("ayda123");
    }

    public void login(){
        driver.findElement(loginLocator).sendKeys();
    }
    public void checkInLogin(){
        driver.findElement(checkInLoginLocator).isDisplayed();
    }
}
