import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

public class SearchPage extends BasePage{

    By inputTextLocator = By.id("search_input");
    By searchLocator = By.cssSelector(".searchButton");
    By moreProductLocator =By.cssSelector(".lazy-load-button > .lazy-load-text");
    By selectLocator =By.id("model_2232683_5522698");


    public SearchPage(WebDriver driver) {
        super(driver);
    }

    public void inputText(){
        driver.findElement(inputTextLocator).sendKeys("pantolon");
    }
    public void search(){
        driver.findElement(searchLocator).click();
    }
    public void downScroll(){
        JavascriptExecutor jsx = (JavascriptExecutor) driver;
        jsx.executeScript("window.scrollTo(0, document.body.scrollHeight)");
    }
    public void scrollUp(){
        JavascriptExecutor jsx = (JavascriptExecutor) driver;
        jsx.executeScript("window.scrollTo(0,-200)");
    }
    public void moreProduct(){
        driver.findElement(moreProductLocator).click();
    }
    public void select(){
        driver.findElement(selectLocator).click();
    }

}
