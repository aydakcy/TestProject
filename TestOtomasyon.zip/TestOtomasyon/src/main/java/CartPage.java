import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import java.util.function.BooleanSupplier;

public class CartPage extends BasePage{

    By chooseSizeLocator = By.cssSelector(".size-pop-up [key='1']");
    By addToCartLocator = By.id("pd_add_to_cart");
    By priceRegularLocator = By.cssSelector("[class='col-xs-12 price-area'] .price-regular");
    By cartItemPriceLocator = By.cssSelector("[class='rd-cart-item-price mb-15']");
    By quantityPlusLocator = By.id("Cart_AddQuantity_699928924");
    By checkInQuantityLocator = By.cssSelector(".item-quantity-input");
    By deleteCartLocator = By.cssSelector("a[title='Sil']");
    By deleteProductLocator = By.cssSelector(".ins-init-condition-tracking.inverted-modal-button.sc-delete");
    By cartEmptyLocator = By.cssSelector(".cart-empty-title");

    public CartPage(WebDriver driver) {
        super(driver);
    }
    public void chooseSize(){
        driver.findElement(chooseSizeLocator).click();
    }
    public void addToCart(){
        driver.findElement(addToCartLocator).click();
    }
    public String priceRegular(){
        return driver.findElement(priceRegularLocator).getText();
    }
    public String cartItemPrice() {
       return driver.findElement(cartItemPriceLocator).getText();
    }
    public void quantityPlus(){
        driver.findElement(quantityPlusLocator).click();
    }
    public String checkInQuantity(){
       return driver.findElement(checkInQuantityLocator).getText();
    }
    public void deleteCart(){
        driver.findElement(deleteCartLocator).click();
    }
    public void deleteProduct(){
        driver.findElement(deleteProductLocator).click();
    }
    public void cartEmpty(){
        driver.findElement(cartEmptyLocator).isDisplayed();
    }

}
